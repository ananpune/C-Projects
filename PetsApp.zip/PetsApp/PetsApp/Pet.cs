﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetsApp
{
    internal class Pet
    {
        private String Name;
        private String Species;
        private int Age;

        public Pet(string name, string species, int age)
        {
            this.Name = name;
            this.Species = species;
            this.Age = age;
            
        }
        public Pet() { }

        public String Pet_Name
        {
            get { return Name; }
            set { Name = value; }

        }

        public String Pet_Species
        {
            get { return Species; }
            set { Species = value; }
        }

        public int Pet_Age
        {
            get { return Age; }
            set { Age = value; }
        }
    }
}
